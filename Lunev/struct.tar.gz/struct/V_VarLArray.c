#define ERROR(func, reason)	printf ( "ERROR: In function %s, %s.\n", func, reason );

//C Headers
#include <stdio.h>
#include <stdlib.h>

//V_VarLArray Headers
#include "V_VarLArray.h"

//*********************************************************************

V_VarLArray* construct ( unsigned int len )
{
	V_VarLArray* Varr = (V_VarLArray*) malloc ( sizeof(V_VarLArray) );
	if ( Varr <= 0 )
	{
		ERROR("construct", "memory for Varr isn't allocation");
		return NULL;
	}
		
	Varr -> length = len;
	Varr -> array = (Elem_of_Array*) calloc ( len , sizeof(Elem_of_Array) );
	if ( Varr -> array <= 0 )
	{
		ERROR("construct", "memory for Varr -> array isn't allocation");
		return NULL;
	}
	
	Varr -> start = Varr -> array;
	Varr -> end = &( Varr -> array[len-1] );

	return Varr;
}

//*********************************************************************

int insert ( V_VarLArray *Varr, unsigned int pos, Elem_of_Array *elem )
{
	if ( Varr <= 0 )
	{
		ERROR("insert", "*Varr isn't valid" );
		return -1;
	}

	if ( pos > ( Varr -> length ) )
	{
		ERROR("insert", "pos > length of array");
		return -1;
	}

	Varr -> array[pos-1].data =  elem -> data;
	return 0;
}

//*********************************************************************

int relen ( V_VarLArray *Varr, unsigned int nLen )
{
	if ( Varr <= 0 )
	{
		ERROR("insert", "*Varr isn't valid" );
		return -1;
	}
	
	Varr -> array = (Elem_of_Array*) realloc ( Varr -> array, nLen * sizeof(Elem_of_Array) );

	if ( Varr -> array <= 0 )
	{
		ERROR("relen", "memory for Varr -> array isn't allocation");
		return -1;
	}
	
	Varr -> length = nLen;
	Varr -> start = Varr -> array;
	Varr -> end = &(Varr -> array[nLen-1]);
	return 0;	
}

//*********************************************************************

int destruct ( V_VarLArray *Varr )
{
	if ( Varr <= 0 )
	{
		ERROR("insert", "*Varr isn't valid" );
		return -1;
	}

	free ( Varr -> array );
	free ( Varr );
	return 0;
}

//*********************************************************************

int copy ( V_VarLArray *source, V_VarLArray *destination )
{	
	if ( source <= 0 )
	{
		ERROR("copy", "*source isn't valid");
		return -1;
	}
	if ( destination <= 0 )
	{
		ERROR("copy", "*destination isn't valid");
		return -1;
	}
	
	if ( clear ( destination ) < 0 )
	{
		ERROR("copy", "clear destination FAIL");
		return -1;
	}
	
	int len = (source -> length);
	if ( relen ( destination, len ) < 0 )
	{
		ERROR("copy", "relen destination FAIL");
		return -1;
	}

	int i = 0;
	for ( i = 0; i < len; ++i )
		destination -> array[i].data = source -> array[i].data;
}

//*********************************************************************

int clear ( V_VarLArray *Varr )
{
	if ( Varr <= 0 )
	{
		ERROR("clear", "*Varr isn't valid");
		return -1;
	}

	Varr -> length = 0;
	free ( Varr -> array );
	Varr -> start = NULL;
	Varr -> end = NULL;

	return 0;
}

//*********************************************************************

int dump ( V_VarLArray *Varr )
{
	if ( Varr <= 0 )
	{
		ERROR("dump", "*Varr isn't valid");
		return -1;
	}
	
	int i = 0;
	for ( i = 0; i < Varr -> length; ++i )
		printf ( "[%d]: %c	", i, Varr -> array[i].data );
	
	putchar ( '\n' );
	return 0;
}

//*********************************************************************

int size ( V_VarLArray *Varr )
{
	if ( Varr <= 0 )
	{
		ERROR("dump", "*Varr isn't valid");
		return -1;
	}

	return Varr -> length;	
}

//*********************************************************************

Elem_of_Array *start ( V_VarLArray *Varr )
{
	if ( Varr <= 0 )
	{
		ERROR("start", "*Varr isn't valid");
		return NULL;
	}

	return Varr -> start;	
}

//*********************************************************************

Elem_of_Array *end ( V_VarLArray *Varr )
{
	if ( Varr <= 0 )
	{
		ERROR("end", "*Varr isn't valid");
		return NULL;
	}

	return Varr -> end;	
}

//*********************************************************************

Elem_of_Array *take ( V_VarLArray *Varr, unsigned int num )
{
	if ( Varr <= 0 )
	{
		ERROR("take", "Varr isn't valid`");
		return NULL;
	}

	return &(Varr -> array[num-1]);	
}

//*********************************************************************














