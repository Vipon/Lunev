#ifndef V_VarLArray_H_
#define V_VarLArray_H_

//*********************************************************************

typedef struct Elem_of_Array {
	
	char data;
	
} Elem_of_Array;

//*********************************************************************

typedef struct V_VarLArray {
	
	unsigned int length;
	Elem_of_Array *array;
	Elem_of_Array *start;
	Elem_of_Array *end;

} V_VarLArray;

//********************************************************************

V_VarLArray* construct ( unsigned int len );

int insert ( V_VarLArray *Varr, unsigned int pos, Elem_of_Array *elem );
int relen ( V_VarLArray *Varr, unsigned int nLen );
int destruct ( V_VarLArray *Varr );
int copy ( V_VarLArray *source, V_VarLArray *destination );
int clear ( V_VarLArray *Varr );
int dump ( V_VarLArray *Varr );
int size ( V_VarLArray *Varr );

Elem_of_Array *start ( V_VarLArray *Varr );
Elem_of_Array *end ( V_VarLArray *Varr ); 
Elem_of_Array *take ( V_VarLArray *Varr, unsigned int num );

//********************************************************************

#endif //V_VarLArray_H_
