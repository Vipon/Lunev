#include <stdio.h>
#include "V_VarLArray.h"

int main ( int argc, char *argv[] )
{
	V_VarLArray *Varr = construct ( 5 );
	V_VarLArray *Va = construct ( 6 );
	
	Elem_of_Array elem;
	elem.data =  48;
	
	insert ( Varr, 6, &elem );
	insert ( Varr, 3, &elem );

	printf ( "%c\n", Varr -> array[2].data );

	relen ( Varr, 7 );

	dump ( Varr );
	elem.data = 49;
	dump ( Va );

	insert ( Va, 4, &elem );
	printf ( "%c\n", Varr -> array[2].data );

	copy ( Va, Varr );
	printf ( "%c\n", Varr -> array[3].data );

	dump ( Va );
	dump ( Varr );

	destruct ( Va );	
	destruct ( Varr );

	return 0;
}
